
import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.GenericOptionsParser;

/**
 * I DO NOT OWN MOST PART OF THIS CODE, ONLY THE COMMENTED PARTS ARE MINE
 */
public class MapReduce_3 {

    private static int TOTAL = 0;
    private static int MALE = 0;

    public static class TokenizerMapper
            extends Mapper<Object, Text, Text, IntWritable> {

        private final static IntWritable one = new IntWritable(1);
        private Text word = new Text();

        /**
         * M/R software : proportion (in%) of male or female
         * I DID NOT SUCCEED IN DOING THIS ONE (
         */
        public void map(Object key, Text value, Context context)
                throws IOException, InterruptedException {

            // I set the Text into a String object
            String text = value.toString();

            // I split the text by lines and instantiate an array
            String[] lines = text.split("\\r?\\n");

            // variables for the treatments
            String genders = "";
            String[] gender = null;
            String toSet = "";

            // for each line in the array
            for(String line : lines) {

                // I get the part concerning the gender
                genders = line.split(";")[1];

                // I split the genders if there are many
                gender = genders.split(",");

                // for each gender found
                for(String tmp : gender) {

                    // we set different values according to the gender
                    if(tmp.equals("m")) {
                        toSet = "male : ";
                    }
                    else {
                        toSet = "female : ";
                    }

                    // I write the result
                    word.set(toSet);
                    context.write(word, one);
                }
                // I add another term
                context.write(new Text("total : "), one);
            }
        }
    }

    public static class IntSumReducer
            extends Reducer<Text,IntWritable,Text,IntWritable> {

        private IntWritable result = new IntWritable();

        public void reduce(Text key, Iterable<IntWritable> values, Context context)
                throws IOException, InterruptedException {

            int sum = 0;
            IntWritable perc = new IntWritable();

            for(IntWritable val : values) {

                sum += val.get();
            }

            if(key.toString().equals("total : "))
                TOTAL += sum;

            if(key.toString().equals("male : "))
                MALE += sum;

            result.set(sum);

            context.write(key, result);
            if(TOTAL > 0) {
                perc.set(100*MALE/TOTAL);
                context.write(new Text("Male % : "), perc);
            }
        }
    }

    public static void main(String[] args) throws Exception {

        Configuration conf = new Configuration();
        String[] otherArgs = new GenericOptionsParser(conf, args).getRemainingArgs();
        if (otherArgs.length != 2) {
            System.err.println("Usage: MapReduce_3 <in> <out>");
            System.exit(2);
        }

        Job job = new Job(conf, "proportion (in%) of male or female");
        job.setJarByClass(MapReduce_3.class);
        job.setMapperClass(TokenizerMapper.class);
        job.setCombinerClass(IntSumReducer.class);
        job.setReducerClass(IntSumReducer.class);
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(IntWritable.class);
        FileInputFormat.addInputPath(job, new Path(otherArgs[0]));
        FileOutputFormat.setOutputPath(job, new Path(otherArgs[1]));
        System.exit(job.waitForCompletion(true) ? 0 : 1);
    }
}
