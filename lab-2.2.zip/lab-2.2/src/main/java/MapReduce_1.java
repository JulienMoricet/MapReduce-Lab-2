
import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.GenericOptionsParser;

/**
 * I DO NOT OWN MOST PART OF THIS CODE, ONLY THE COMMENTED PARTS ARE MINE
 */
public class MapReduce_1 {

    public static class TokenizerMapper
            extends Mapper<Object, Text, Text, IntWritable> {

        private final static IntWritable one = new IntWritable(1);
        private Text word = new Text();

        /**
         * M/R software : count name by origins
         */
        public void map(Object key, Text value, Context context)
                throws IOException, InterruptedException {

            // I set the Text into a String object
            String text = value.toString();

            // I split the text by lines and instantiate an array
            String[] lines = text.split("\\r?\\n");

            // variables for the treatments
            String origins = "";
            String[] origin = null;
            String[] elements = null;

            // for each line in the array
            for(String line : lines) {

                // I get the part concerning the origin
                origins = line.split(";")[2];

                // I split the origins if there are many
                origin = origins.split(", ");

                // for each origin found
                for(String tmp : origin) {

                    // I split a last time for a few exception
                    elements = tmp.split(",");

                    // for each element found
                    for(String element : elements) {

                        // I write the result
                        word.set(element);
                        context.write(word, one);
                    }
                }
            }
        }
    }

    public static class IntSumReducer
            extends Reducer<Text,IntWritable,Text,IntWritable> {

        private IntWritable result = new IntWritable();

        public void reduce(Text key, Iterable<IntWritable> values, Context context)
                throws IOException, InterruptedException {

            int sum = 0;

            for(IntWritable val : values) {

                sum += val.get();
            }
            result.set(sum);
            context.write(key, result);
        }
    }

    public static void main(String[] args) throws Exception {

        Configuration conf = new Configuration();
        String[] otherArgs = new GenericOptionsParser(conf, args).getRemainingArgs();
        if (otherArgs.length != 2) {
            System.err.println("Usage: MapReduce_1 <in> <out>");
            System.exit(2);
        }

        Job job = new Job(conf, "count name by origins");
        job.setJarByClass(MapReduce_1.class);
        job.setMapperClass(TokenizerMapper.class);
        job.setCombinerClass(IntSumReducer.class);
        job.setReducerClass(IntSumReducer.class);
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(IntWritable.class);
        FileInputFormat.addInputPath(job, new Path(otherArgs[0]));
        FileOutputFormat.setOutputPath(job, new Path(otherArgs[1]));
        System.exit(job.waitForCompletion(true) ? 0 : 1);
    }
}